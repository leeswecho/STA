STA - Seize The Advantage Readme
--------------------------------

Contents of this Package:

/config directory: Where the game configuration files are.
/debuglogs: everytime a game is run, a log file of the game operation for debugging purposes is generated here.
/maps: if you want the game to be able to access a map, put it here.
/media: contains all the sounds, graphics, and music

MapConv2.06 : this is a converter tool that turns 256-color .bmp files into empty map files used by the game.
STA_4dXX.exe : this is the program.




Tutorial
----------
To play through a brief walkthrough of how this game works, start a single player game, and choose Tutorial.map as your map.




Configuration Options
---------------------
If you go to the /config directory, and open the general_configuration.ini, there are a number of options you can change. Change these if for some reason you can't get the game to run in the default configuration. 

      1. Game is not drawing correctly
      ---------------------------------
      Try [DDRM] {SYSMEM}  
      DDRM governs the drawing process that the game uses. Sometimes, for whatever reason, you might run out of video memory and the game won't start, or not draw correctly. SYSMEM loads everything into (usually more available) main memory, at the expense of some speed.

          
      2. I want to force the game to run at a certain resolution
      ----------------------------------------------------------
      Use [SETRES] {xres, yres, bitdepth}
      Make sure it is before the tilde (~)

      3. The game is jerky and I am getting "HP Timer de-sync" errors in-game
      -----------------------------------------------------------------------
      Set [TIMERTHREAD] {TRUE}
      On some multiprocessor / multicore systems, the high-performance timer implementation is flawed, and the times reported by each processor are different.
      This causes the jerking. 
The dedicated timer thread is initialized to only run on one core, thus receiving the timing data from only that source. 

